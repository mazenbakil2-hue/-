// 1. تشغيل مكتبة الحركات AOS
AOS.init({
    duration: 1000,
    once: true,
    offset: 100
});

// 2. شاشة التحميل الذكية
window.addEventListener('load', () => {
    const loader = document.getElementById('loader');
    setTimeout(() => {
        loader.style.opacity = '0';
        setTimeout(() => loader.style.display = 'none', 500);
    }, 1500);
});

// 3. تأثير الضوء الذي يتبع الماوس (Magic Glow)
// هذا التأثير يضيف هالة ضوئية تتحرك مع الماوس في خلفية الموقع
const hero = document.querySelector('.hero');
hero.addEventListener('mousemove', (e) => {
    const { clientX, clientY } = e;
    const x = clientX / window.innerWidth * 100;
    const y = clientY / window.innerHeight * 100;
    hero.style.setProperty('--x', `${x}%`);
    hero.style.setProperty('--y', `${y}%`);
});

// 4. تأثير الناف بار عند التمرير
window.addEventListener('scroll', () => {
    const nav = document.querySelector('.main-nav');
    if (window.scrollY > 50) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});

// 5. تأثير الكتابة الآلية لاسمك في الكونسول (حركة برمجية بسيطة ورهيبة)
console.log("%cتم التطوير بواسطة: المهندس مازن بكيل", "color: #cd9d52; font-size: 20px; font-weight: bold; text-shadow: 0 0 10px rgba(205, 157, 82, 0.5);");

// 6. إضافة تفاعل لصور المعرض (تغيير الإضاءة عند اللمس)
const galleryItems = document.querySelectorAll('.gallery-item');
galleryItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        item.style.filter = "brightness(1.2) contrast(1.1)";
        item.style.boxShadow = "0 0 30px rgba(205, 157, 82, 0.4)";
    });
    item.addEventListener('mouseleave', () => {
        item.style.filter = "brightness(1)";
        item.style.boxShadow = "none";
    });
});
